public class Pop extends Command {
    int arg2;
    String fileName;

    public Pop(String arg1, int arg2, int id, String fileName) {
        super(arg1, id);
        this.arg2 = arg2;
        this.fileName = fileName;
    }

    @Override
    public String translate() {
        StringBuilder code = new StringBuilder();

        switch(arg1) {
            case "local":
            case "argument":
            case "this":
            case "that":
                translateLATT(code);
                break;
            case "static":
                translateStatic(code);
                break;
            case "temp":
                translateTemp(code);
                break;
            case "pointer":
                translatePointer(code);
            default:
        }

        return code.toString();
    }

    private void translateLATT(StringBuilder code) {
        String segmentPointer = getPointer();
        code.append("@" + arg2 + "\n" +
                    "D=A;\n" +
                    "@" + segmentPointer + "\n" +
                    "D=D+M;\n" +
                    "@SP\n" +
                    "AM=M-1;\n" +
                    "D=D+M;\n" +
                    "A=D-M;\n" +
                    "M=D-A;\n");
    }

    private String getPointer() {
        switch(arg1) {
            case "local": return "LCL";
            case "argument": return "ARG";
            case "this": return "THIS";
            case "that": return "THAT";
            default:
        }
        return null;
    }

    private void translateStatic(StringBuilder code) {
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "@" + fileName + "." + arg2 + "\n" +
                    "M=D;\n");
    }

    private void translateTemp(StringBuilder code) {
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "@" + (5 + arg2) + "\n" +
                    "M=D;\n");
    }

    private void translatePointer(StringBuilder code) {
        String segmentPointer = arg2 == 0 ? "THIS" : "THAT";
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "@" + segmentPointer + "\n" +
                    "M=D;\n");
    }
}
