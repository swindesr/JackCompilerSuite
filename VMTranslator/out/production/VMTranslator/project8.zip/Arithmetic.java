public class Arithmetic extends Command {

    public Arithmetic(String arg1, int id) {
        super(arg1, id);
    }

    @Override
    public String translate() {
        StringBuilder code = new StringBuilder();
        switch(arg1) {
            case "add":
            case "sub":
                translateAddSub(code);
                break;
            case "neg":
            case "not":
                translateNegNot(code);
                break;
            case "and":
            case "or":
                translateAndOr(code);
                break;
            case "eq":
            case "gt":
            case "lt":
                translateEqGtLt(code);
                break;
            default:
        }

        return code.toString();
    }

    private void translateAddSub(StringBuilder code) {
        String operator = arg1.equals("add") ? "+" : "-";
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "A=A-1;\n" +
                    "M=M" + operator + "D;\n");
    }

    private void translateNegNot(StringBuilder code) {
        String operator = arg1.equals("neg") ? "-" : "!";
        code.append("@SP\n" +
                    "A=M-1;\n" +
                    "M=" + operator + "M;\n");
    }

    private void translateAndOr(StringBuilder code) {
        String operator = arg1.equals("and") ? "&" : "|";
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "A=A-1;\n" +
                    "M=D" + operator + "M;\n");
    }

    private void translateEqGtLt(StringBuilder code) {
        String operator;
        if (arg1.equals("eq")) {
            operator = "JEQ";
        } else if (arg1.equals("gt")) {
            operator = "JGT";
        } else {
            operator = "JLT";
        }
        code.append("@SP\n" +
                    "AM=M-1;\n" +
                    "D=M;\n" +
                    "A=A-1;\n" +
                    "D=M-D;\n" +
                    "@IF_TRUE" + id + "\n" +
                    "D;" + operator + "\n" +
                    "@SP\n" +
                    "A=M-1;\n" +
                    "M=0;\n" +
                    "@IF_END" + id + "\n" +
                    "0;JMP\n" +
                    "(IF_TRUE" + id + ")\n" +
                    "@SP\n" +
                    "A=M-1;\n" +
                    "M=-1;\n" +
                    "(IF_END" + id + ")\n");
    }
}
