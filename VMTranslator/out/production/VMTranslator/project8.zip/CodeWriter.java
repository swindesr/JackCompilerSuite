public class CodeWriter {
    String fileName;

    public CodeWriter(String fileName) {
        this.fileName = fileName;
    }
    public CodeWriter(){}

    public String translate() {
        StringBuilder code = new StringBuilder();
        Parser p = new Parser(fileName);
        p.parse();

        p.getCommands().stream().forEach(command -> code.append(command.translate()));

        return code.toString();
    }

    public String writeStartupCode() {
        StringBuilder code = new StringBuilder();
        code.append("@256\n" +
                    "D=A;\n" +
                    "@0\n" +
                    "M=D;\n");

        code.append(new Call("Sys.init", 0, -1, "Sys.vm").translate());

        return code.toString();
    }
}
