import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class CompilationEngine {
    private LinkedList<Token> tokens;
    private List<Token> compiledTokens;
    private SymbolTable symbolTable;
    private VMWriter writer;
    private String className;
    private int whileCount, ifCount = 0;

    public CompilationEngine(LinkedList<Token> analyzedTokens, String fileName) {
        tokens = analyzedTokens;
        compiledTokens = new LinkedList<>();
        symbolTable = new SymbolTable();
        className = tokens.get(1).value;
        writer = new VMWriter(fileName, className);
        compileClass();
        writer.close();
    }

    private void compileClass() {
        // get first token (should be CLASS)
        compiledTokens.add(tokens.poll());

        // retrieve class identifier
        compiledTokens.add(tokens.poll());

        // retrieve { symbol
        compiledTokens.add(tokens.poll());

        // compile variable/field declarations
        compileClassVarDec();

        // compile subroutine declarations
        compileSubroutineDec();

        // retrieve } symbol
        compiledTokens.add(tokens.poll());
    }

    private void compileClassVarDec() {
        // Look at next token and if it begins a variable declaration, compile it
        String next = tokens.peek().value;
        while (next.equals("static") || next.equals("field")) {

            varDecWithSymbols();

            // retrieve ; symbol ending current set of declarations
            compiledTokens.add( tokens.poll());

            next = tokens.peek().value;
        }
    }

    private void compileSubroutineDec() {
        // Look at next token and if it begins a subroutine declaration, compile it
        String next = tokens.peek().value;
        while (next.equals("function") || next.equals("method") || next.equals("constructor")) {

            symbolTable.startSubroutine();
            if (next.equals("method")) {
                symbolTable.define("this", className, "arg");
            }

            // add beginning keyword
            compiledTokens.add(tokens.poll());
            // add return type
            compiledTokens.add(tokens.poll());
            // add name
            String functionName = tokens.peek().value;
            compiledTokens.add(tokens.poll());
            // add parameter list
            compileParameterList();
            // add body
            compileSubroutineBody(functionName, next);

            next = tokens.peek().value;
        }
    }

    private void compileParameterList() {
        // retrieve (
        compiledTokens.add(tokens.poll());

        // add each token in parameter list, halting at )
        String next = tokens.peek().value;
        while (!next.equals(")")) {
            if (next.equals(",")) { compiledTokens.add(tokens.poll()); }
            String type = tokens.peek().value;
            compiledTokens.add(tokens.poll());

            symbolTable.define(tokens.peek().value, type, "arg");
            compiledTokens.add( tokens.poll());
            next = tokens.peek().value;
        }

        // retrieve )
        compiledTokens.add(tokens.poll());
    }

    private void compileSubroutineBody(String name, String kind) {
        // retrieve { symbol
        compiledTokens.add(tokens.poll());

        // add all variable declarations
        compileVarDec();
        writer.writeFunction(name, symbolTable.varCount("local"));

        if (kind.equals("method")) {
            writer.writePush("argument", 0);
            writer.writePop("pointer", 0);
        } else if (kind.equals("constructor")) {
            writer.writePush("constant", symbolTable.varCount("field"));
            writer.writeCall("Memory.alloc", 1);
            writer.writePop("pointer", 0);
        }

        // add all statements
        compileStatements();

        // retrieve } symbol
        compiledTokens.add(tokens.poll());
    }

    private void compileVarDec() {
        // get each variable declaration and compile
        String next = tokens.peek().value;
        while (next.equals("var")) {

            varDecWithSymbols();

            // retrieve ; symbol ending current set of declarations
            compiledTokens.add(tokens.poll());

            next = tokens.peek().value;
        }
    }

    private void compileStatements() {
        // Look at each statement and compile accordingly
        String next = tokens.peek().value;
        while (next.equals("let")
                || next.equals("if")
                || next.equals("while")
                || next.equals("do")
                || next.equals("return")) {

            switch(next) {
                case "let":     compileLet();
                                break;
                case "if":      compileIf();
                                break;
                case "while":   compileWhile();
                                break;
                case "do":      compileDo();
                                break;
                case "return":  compileReturn();
                                break;
            }

            next = tokens.peek().value;
        }
    }

    private void compileLet() {
        // add statement keyword
        compiledTokens.add(tokens.poll());

        // add varName
        String name = tokens.peek().value;
        String kind = symbolTable.kindOf(name);
        int index = symbolTable.indexOf(name);
        compiledTokens.add(tokens.poll());

        // add expressions, possibly [ ]
        String next = tokens.peek().value;
        if (next.equals("[")) {
            compiledTokens.add(tokens.poll()); // [
            compileExpression();
            writer.writePush(symbolTable.kindOf(name), symbolTable.indexOf(name));
            compiledTokens.add(tokens.poll()); // ]
            writer.writeArithmetic("+");

            compiledTokens.add(tokens.poll()); // =
            compileExpression();
            writer.writePop("temp", 0);
            writer.writePop("pointer", 1);
            writer.writePush("temp", 0);
            writer.writePop("that", 0);
        } else {
            // add = symbol
            compiledTokens.add(tokens.poll());

            // add expression
            compileExpression();
            writer.writePop(kind, index);
        }


        // add ; symbol
        compiledTokens.add(tokens.poll());
    }

    private void compileIf() {
        int id = ifCount;
        ifCount++;

        // add statement keyword
        compiledTokens.add(tokens.poll());

        // add ( symbol
        compiledTokens.add(tokens.poll());

        // add expression
        compileExpression();
        writer.writeArithmetic("!");
        writer.writeIf("IF_TRUE" + id);

        // add ) symbol
        compiledTokens.add(tokens.poll());

        // add { symbol
        compiledTokens.add(tokens.poll());

        // add statements
        compileStatements();

        // add } symbol
        compiledTokens.add(tokens.poll());

        String next = tokens.peek().value;
        if (next.equals("else")) {
            writer.writeGoto("IF_FALSE" + id);
            // add else
            compiledTokens.add(tokens.poll());

            // add { symbol
            compiledTokens.add(tokens.poll());

            // add statements
            writer.writeLabel("IF_TRUE" + id);
            compileStatements();
            writer.writeLabel("IF_FALSE" + id);

            // add } symbol
            compiledTokens.add(tokens.poll());
        } else {
            writer.writeLabel("IF_TRUE" + id);
        }
    }

    private void compileWhile() {
        int id = whileCount;
        whileCount++;

        writer.writeLabel("WHILE_EXP" + id);

        // add statement keyword
        compiledTokens.add(tokens.poll());

        // add ( symbol
        compiledTokens.add(tokens.poll());

        // add expression
        compileExpression();
        writer.writeArithmetic("!");
        writer.writeIf("WHILE_END" + id);

        // add ) symbol
        compiledTokens.add(tokens.poll());

        // add { symbol
        compiledTokens.add(tokens.poll());

        // add statements
        compileStatements();
        writer.writeGoto("WHILE_EXP" + id);
        writer.writeLabel("WHILE_END" +id);

        // add } symbol
        compiledTokens.add(tokens.poll());
    }

    private void compileDo() {
        // add statement keyword
        compiledTokens.add(tokens.poll());

        // add subroutine call name
        String name = tokens.peek().value;
        int numArgs = symbolTable.contains(name) ? 1 : 0;
        compiledTokens.add(tokens.poll()); // name | ( className | varName )

        // determine call type,
        String next = tokens.peek().value;
        if (next.equals("(")) {
            compiledTokens.add(tokens.poll()); // (
            writer.writePush("pointer", 0);
            numArgs += compileExpressionList() + 1;
            compiledTokens.add(tokens.poll()); // )
            name = className + "." + name;
        } else {
            compiledTokens.add(tokens.poll()); // .
            if (symbolTable.contains(name)) {
                writer.writePush(symbolTable.kindOf(name), symbolTable.indexOf(name));
                name = symbolTable.typeOf(name);
            }
            name = name + "." + tokens.peek().value;
            compiledTokens.add(tokens.poll()); // name
            compiledTokens.add(tokens.poll()); // (
            numArgs += compileExpressionList();
            compiledTokens.add(tokens.poll()); // )
        }

        // add ; symbol
        compiledTokens.add(tokens.poll());

        writer.writeCall(name, numArgs);
        writer.writePop("temp", 0);
    }

    private void compileReturn() {
        compiledTokens.add(new Token(TokenType.XML_LABEL, "<returnStatement>"));

        // add statement keyword
        compiledTokens.add(tokens.poll());

        // add expressions
        if (tokens.peek().value.equals(";")) {
            writer.writePush("constant", 0);
        } else {
            compileExpression();
        }

        // add ; symbol
        compiledTokens.add(tokens.poll());

        writer.writeReturn();
        compiledTokens.add(new Token(TokenType.XML_LABEL, "</returnStatement>"));
    }

    private void compileExpression() {
        compiledTokens.add(new Token(TokenType.XML_LABEL, "<expression>"));

        // add all terms
        compileTerm();

        String next = tokens.peek().value; // get following symbol
        while (!next.equals(",") && !next.equals(")") && !next.equals("]") && !next.equals(";")) {
            compiledTokens.add(tokens.poll()); // add operator
            compileTerm();
            writer.writeArithmetic(next);
            next = tokens.peek().value;
        }

        compiledTokens.add(new Token(TokenType.XML_LABEL, "</expression>"));
    }

    private void compileTerm() {
        // determine term type and handle accordingly
        Token next = tokens.peek();
        // varName or subroutineCall
        if (next.type.equals(TokenType.IDENTIFIER)) {
            compiledTokens.add(tokens.poll());
            String name = next.value;
            int nArgs = 0;
            next = tokens.peek();
            if (next.value.equals("[")) { // array
                compiledTokens.add(tokens.poll()); // [
                compileExpression();
                writer.writePush(symbolTable.kindOf(name), symbolTable.indexOf(name));
                compiledTokens.add(tokens.poll()); // ]
                writer.writeArithmetic("+");
                writer.writePop("pointer", 1);
                writer.writePush("that", 0);
            }  else if (next.value.equals("(")) { // subroutineCall name(###
                compiledTokens.add(tokens.poll()); // (
                compileExpressionList();
                compiledTokens.add(tokens.poll()); // )
            } else if (next.value.equals(".")){ // subroutineCall name.###
                compiledTokens.add(tokens.poll()); // .
                if (symbolTable.contains(name)) {
                    writer.writePush(symbolTable.kindOf(name), symbolTable.indexOf(name));
                    nArgs++;
                }
                String methodName = "." + tokens.peek().value;
                compiledTokens.add(tokens.poll()); // name
                compiledTokens.add(tokens.poll()); // (
                nArgs += compileExpressionList();
                compiledTokens.add(tokens.poll()); // )
                if (symbolTable.contains(name)) {
                    writer.writeCall(symbolTable.typeOf(name) + methodName, nArgs);
                } else {
                    writer.writeCall(name + methodName, nArgs);
                }
            } else if (symbolTable.contains(name)) {
                writer.writePush(symbolTable.kindOf(name), symbolTable.indexOf(name));
            }
        } else if (next.value.equals("(")) { // ( expression )
            compiledTokens.add(tokens.poll()); // (
            compileExpression();
            compiledTokens.add(tokens.poll()); // )
        } else if (next.value.equals("~")) { // unaryOp term
            compiledTokens.add(tokens.poll());
            compileTerm();
            writer.writeArithmetic("!");
        } else if (next.value.equals("-")) {
            compiledTokens.add(tokens.poll());
            compileTerm();
            writer.writeArithmetic("~");
        } else if (next.type == TokenType.KEYWORD) {
            switch(next.value) {
                case "true":    writer.writePush("constant", 1);
                                writer.writeArithmetic("~");
                                break;
                case "false":   writer.writePush("constant", 0);
                                break;
                case "this":    writer.writePush("pointer", 0);
                                break;
                case "null":    writer.writePush("constant", 0);
            }
            compiledTokens.add(tokens.poll());
        } else {
            if (tokens.peek().type == TokenType.STRING_CONST) {
                Token stringToken = tokens.poll();
                compiledTokens.add(stringToken);
                char[] string = stringToken.value.substring(1, stringToken.value.length() - 1).toCharArray();
                writer.writePush("constant", string.length);
                writer.writeCall("String.new", 1);
                for (int i = 0; i < string.length; i++) {
                    writer.writePush("constant", string[i]);
                    writer.writeCall("String.appendChar", 2);
                }
            } else {
                writer.writePush("constant", Integer.parseInt(tokens.peek().value));
                compiledTokens.add(tokens.poll());
            }
        }
    }

    private int compileExpressionList() {
        // compile all expressions in list
        String next = tokens.peek().value;
        int numArgs = 0;
        while (!next.equals(")")) {
            if (numArgs > 0) { compiledTokens.add(tokens.poll()); }
            compileExpression();
            numArgs++;
            next = tokens.peek().value;
        }

        return numArgs;
    }

    private void varDecWithSymbols() {
        String kind = tokens.peek().value;
        compiledTokens.add(tokens.poll());

        String type = tokens.peek().value;
        compiledTokens.add(tokens.poll());

        while (!(tokens.peek().value.equals(";"))) {
            if (tokens.peek().type == TokenType.IDENTIFIER) {
                symbolTable.define(tokens.peek().value, type, kind);
            }
            compiledTokens.add(tokens.poll());
        }
    }

    public void writeToXMLFile(String fileName) {
        try {
            FileWriter file = new FileWriter(fileName);
            BufferedWriter writer = new BufferedWriter(file);
            for (Token token: compiledTokens) {
                writer.write(token.value);
                writer.newLine();
            }
            writer.close();
        } catch (IOException x) {
            System.err.format("IOException: %s%n", x);
        }
    }

}
